export const apiUrl = {
    
    key : "83e51a92af33e7b2703ea7db03f8fa11",
    base : "https://api.themoviedb.org/3/",
    getGenres : "genre/movie/list",
    nowPlaying : "movie/now_playing",
    language : "language=en-US",
    imageBase : "https://image.tmdb.org/t/p/w500"
}
