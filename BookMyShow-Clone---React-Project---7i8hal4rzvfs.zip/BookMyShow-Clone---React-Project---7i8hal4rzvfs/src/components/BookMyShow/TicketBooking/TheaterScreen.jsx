import React from 'react'
import './TicketBooking.css'
import screen from '../../utills/images/screen.png'
export function TheaterScreen() {
  return (
    <div className='theater-screen'>
        <img src={screen} alt="theater screen" />
    </div>
  )
}
